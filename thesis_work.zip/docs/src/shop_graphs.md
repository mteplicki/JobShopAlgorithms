# ShopGraphs

Package `ShopGraphs` provides a set of functions for working with graphs dedicated to the Job Shop Scheduling Problem.

```@autodocs
Modules = [ShopGraphs]
Order   = [:constant, :type, :function]
Private = false
```

