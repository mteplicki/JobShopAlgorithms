# ShopInstances

Package to define and work with instances of the Job Shop Scheduling Problem.

```@autodocs
Modules = [ShopInstances]
Order   = [:constant, :type, :function]
Private = false
```