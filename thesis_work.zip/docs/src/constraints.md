# Constraints

Package `Constrains` provides a set of functions for working with constraints dedicated to the Job Shop Scheduling Problem.

```@autodocs
Modules = [Constraints]
Order   = [:constant, :type, :function]
Private = false
```