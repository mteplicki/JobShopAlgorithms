export AbstractShop

"""
    AbstractShop

Abstract type representing a shop problem.
"""
abstract type AbstractShop end
